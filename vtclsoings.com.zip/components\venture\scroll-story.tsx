"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { motion, useReducedMotion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { ArrowDown, ArrowUpRight } from "lucide-react";

interface PhotoConfig {
  image: string;
  alt: string;
  className: string;
  rotation: number;
  targetX: number;
  targetY: number;
  scrollRange: [number, number, number, number, number];
  xRatios: [number, number, number, number, number];
  yRatios: [number, number, number, number, number];
  rotateZFrames: [number, number, number, number, number];
  scaleFrames: [number, number, number, number, number];
  opacityFrames: [number, number, number, number, number];
}

const photos: PhotoConfig[] = [
  {
    image: "/images/family-home.webp",
    alt: "A family sharing a happy moment outside their home",
    className: "photo-one",
    rotation: -11,
    targetX: 640,
    targetY: 740,
    scrollRange: [0, 0.12, 0.24, 0.36, 0.44],
    xRatios: [0, 0.14, 0.45, 0.82, 1],
    yRatios: [0, 0.16, 0.50, 0.86, 1],
    rotateZFrames: [-11, -9, -6, -3, 0],
    scaleFrames: [1, 0.95, 0.76, 0.36, 0],
    opacityFrames: [1, 1, 0.88, 0.35, 0],
  },
  {
    image: "/images/moving-day.webp",
    alt: "A family carrying boxes into their new home",
    className: "photo-two",
    rotation: 10,
    targetX: -640,
    targetY: 720,
    scrollRange: [0, 0.15, 0.28, 0.40, 0.48],
    xRatios: [0, 0.14, 0.46, 0.84, 1],
    yRatios: [0, 0.15, 0.48, 0.85, 1],
    rotateZFrames: [10, 8, 5, 2, 0],
    scaleFrames: [1, 0.96, 0.78, 0.38, 0],
    opacityFrames: [1, 1, 0.90, 0.38, 0],
  },
  {
    image: "/images/home-detail.webp",
    alt: "The small details that make a house feel like home",
    className: "photo-three",
    rotation: -8,
    targetX: 620,
    targetY: 420,
    scrollRange: [0, 0.18, 0.32, 0.44, 0.52],
    xRatios: [0, 0.15, 0.48, 0.85, 1],
    yRatios: [0, 0.14, 0.46, 0.84, 1],
    rotateZFrames: [-8, -6, -4, -2, 0],
    scaleFrames: [1, 0.95, 0.76, 0.35, 0],
    opacityFrames: [1, 1, 0.88, 0.35, 0],
  },
];

function FloatingPhoto({
  photo,
  progress,
  scaleFactor,
}: {
  photo: PhotoConfig;
  progress: MotionValue<number>;
  scaleFactor: number;
}) {
  const x = useTransform(
    progress,
    photo.scrollRange,
    photo.xRatios.map((r) => r * photo.targetX * scaleFactor)
  );
  const y = useTransform(
    progress,
    photo.scrollRange,
    photo.yRatios.map((r) => r * photo.targetY * scaleFactor)
  );
  const rotate = useTransform(progress, photo.scrollRange, photo.rotateZFrames);
  const scale = useTransform(progress, photo.scrollRange, photo.scaleFrames);
  const opacity = useTransform(progress, photo.scrollRange, photo.opacityFrames);
  const visibility = useTransform(progress, (v) => (v >= photo.scrollRange[4] ? "hidden" : "visible"));

  return (
    <motion.figure
      className={`floating-photo ${photo.className}`}
      style={{
        x,
        y,
        rotate,
        scale,
        opacity,
        visibility,
      }}
    >
      <Image src={photo.image} alt={photo.alt} fill sizes="(max-width: 600px) 28vw, 19vw" priority unoptimized />
    </motion.figure>
  );
}

function FloatingNote({
  progress,
  scaleFactor,
}: {
  progress: MotionValue<number>;
  scaleFactor: number;
}) {
  const scrollRange = [0, 0.20, 0.34, 0.46, 0.54] as const;
  const x = useTransform(
    progress,
    scrollRange,
    [0, -560 * scaleFactor * 0.14, -560 * scaleFactor * 0.48, -560 * scaleFactor * 0.85, -560 * scaleFactor]
  );
  const y = useTransform(
    progress,
    scrollRange,
    [0, 360 * scaleFactor * 0.12, 360 * scaleFactor * 0.44, 360 * scaleFactor * 0.85, 360 * scaleFactor]
  );
  const rotate = useTransform(progress, scrollRange, [0, -2, -1, 0, 0]);
  const scale = useTransform(progress, scrollRange, [1, 0.96, 0.78, 0.35, 0]);
  const opacity = useTransform(progress, scrollRange, [1, 1, 0.88, 0.35, 0]);
  const visibility = useTransform(progress, (v) => (v >= 0.54 ? "hidden" : "visible"));

  return (
    <motion.aside
      className="floating-note"
      style={{
        x,
        y,
        rotate,
        scale,
        opacity,
        visibility,
      }}
      aria-hidden="true"
    >
      <span className="note-icon">★</span>
      <span>5.0 Rated<small>Trusted across Michigan</small></span>
    </motion.aside>
  );
}

export function ScrollStory() {
  const ref = useRef<HTMLElement>(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const textY = useTransform(scrollYProgress, [0, 1], [0, -70]);
  const textOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0.2]);

  const [scaleFactor, setScaleFactor] = useState(1);
  useEffect(() => {
    const update = () => {
      const w = window.innerWidth;
      if (w >= 1400) setScaleFactor(1);
      else if (w >= 1100) setScaleFactor(0.85);
      else if (w >= 850) setScaleFactor(0.68);
      else if (w >= 600) setScaleFactor(0.5);
      else setScaleFactor(0.38);
    };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  return (
    <section ref={ref} id="top" className="scroll-story">
      <div className="story-stage">
        <div className="atmosphere" aria-hidden="true" />
        <motion.div className="story-heading" style={reduced ? {} : { y: textY, opacity: textOpacity }}>
          <p className="intro-pill"><span /> A Michigan team. A more personal closing.</p>
          <h1>Good things<br/>start with <em>home.</em></h1>
          <p className="hero-subtitle">The first keys. The next chapter. The place that’s yours.<br/>We handle the title and closing. You make it home.</p>
          <div className="hero-ctas">
            <a className="button button-primary" href="https://vtclosings.com/order-title/">Let’s make it yours <ArrowUpRight size={18}/></a>
            <a className="quiet-link" href="#difference">Meet Venture <ArrowUpRight size={17}/></a>
          </div>
          <a className="scroll-invitation" href="#difference">
            <span>EVERY PIECE COMES TOGETHER</span>
            <ArrowDown size={17}/>
          </a>
        </motion.div>
        {!reduced && photos.map(photo => (
          <FloatingPhoto key={photo.className} photo={photo} progress={scrollYProgress} scaleFactor={scaleFactor} />
        ))}
        {!reduced && <FloatingNote progress={scrollYProgress} scaleFactor={scaleFactor} />}
      </div>
    </section>
  );
}

