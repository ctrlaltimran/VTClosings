# Content sources

Verified September 9, 2026. This homepage links to the company's existing order and contact workflows; it does not receive or store client transaction data.

- https://vtclosings.com/about-us/ — Michigan service area, staff experience handling thousands of closings, published address and telephone.
- https://vtclosings.com/services/consumers/ — buyer and seller services, single point of contact, title commitments and communication.
- https://vtclosings.com/services/lenders/ — First American and WFG underwriters.
- https://vtclosings.com/order-title/ — existing order form destination.
- https://wanderlog.com/place/details/12565921/venture-title-agency — three short client-review excerpts, reviewer names, and dates (23 quoted words total).

No numerical founding year, satisfaction percentage, or exact closing count was supplied. These are intentionally not invented. The statistics strip uses supported qualitative facts instead.

The typography-based Venture identity and 3D architecture are design concepts. Underwriter names are typeset identifiers rather than purported official logo assets.

## Photography and redesign

The September 9 redesign takes inspiration from the user's supplied Portrait screenshots: centered type, soft color, floating photography and a scroll-driven composition. It uses original layouts and Venture-specific copy.

Real stock photography (people pictured are illustrative, not represented as Venture clients):

- `public/images/family-home.webp`: RDNE Stock project — https://www.pexels.com/photo/parents-carrying-a-boy-standing-near-glass-windows-with-blinds-8209985/
- `public/images/moving-day.webp`: MART PRODUCTION — https://www.pexels.com/photo/a-newly-moved-family-carrying-cardboard-boxes-7415024/
- `public/images/home-detail.webp`: Ingo Joseph — https://www.pexels.com/photo/gray-ikon-keys-on-brown-wooden-surface-14721/
- License: https://www.pexels.com/license/

Photos are locally served WebP files. DM Sans and Instrument Serif are served locally through Fontsource. No generated imagery is used.

## Implementation

Next.js App Router conventions, React 19, TypeScript, Tailwind, Framer Motion, React Three Fiber/Drei, Lenis, next-themes, and bundled shadcn Dialog, Accordion and Tabs. Sites uses Vinext for the hosted Cloudflare build. The 3D scene loads near the closing-process section and animates only while that section is in view. Reduced-motion mode presents the photographic story statically without a long sticky-scroll sequence.
